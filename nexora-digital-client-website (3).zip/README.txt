NEXORA DIGITAL — CLIENT WEBSITE
=================================

1. Open index.html to preview the website.
2. Replace:
   - 91XXXXXXXXXX with your WhatsApp number
   - YOURMAIL@example.com with your email
   - @yourhandle with your Instagram username
3. Replace the portfolio placeholder cards with your real work.
4. Upload index.html to a free static host such as GitHub Pages or another static hosting service.
5. When you buy a domain later, connect the domain to the hosting.

PRICING NOTE
The prices in this starter website are intentionally positioned as accessible freelancer/small-business starting prices, not as a claim that every Indian provider charges the same. Market pricing varies widely by scope.
